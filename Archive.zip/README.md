# Connect Four
A real time connect 4 game build with Javascript.

## Install and Run
`git clone https://github.com/mackness/connect-four.git`


1. cd connect-four
2. npm install
3. npm start
4. navigate to http://localhost:3000 in your browser of choice.